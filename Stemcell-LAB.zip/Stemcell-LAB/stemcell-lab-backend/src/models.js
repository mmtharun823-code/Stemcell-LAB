import mongoose from 'mongoose'

const options = { timestamps: true, versionKey: false }
export const User = mongoose.model('User', new mongoose.Schema({
  name: { type: String, required: true }, email: { type: String, required: true, unique: true, index: true },
  passwordHash: { type: String, required: true }, role: { type: String, enum: ['Admin', 'Lab Technician', 'Researcher', 'Compliance Officer'], required: true },
}, options))
export const Donor = mongoose.model('Donor', new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true }, pseudonymousCode: { type: String, required: true },
  consentStatus: { type: String, enum: ['Pending', 'Submitted', 'Verified', 'Needs Review', 'Withdrawn'], required: true },
  consentVerificationDate: Date,
}, options))
export const Sample = mongoose.model('Sample', new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true }, donor: { type: String, required: true, index: true },
  type: { type: String, required: true }, project: String, received: Date, location: String,
  status: { type: String, enum: ['Registered', 'Received', 'Quality Review', 'Stored', 'On Hold', 'Rejected', 'Archived'], default: 'Registered', index: true },
  notes: String,
}, options))
export const CultureBatch = mongoose.model('CultureBatch', new mongoose.Schema({
  id: { type: String, required: true, unique: true, index: true }, sampleIds: [String], project: String, researcher: String,
  status: { type: String, enum: ['Planned', 'In Progress', 'Observation Due', 'Quality Review', 'Completed', 'On Hold', 'Archived'], default: 'Planned' },
}, options))
export const StorageLocation = mongoose.model('StorageLocation', new mongoose.Schema({
  id: { type: String, required: true, unique: true }, facility: String, unit: String, position: String, capacity: Number, occupied: Number,
}, options))
export const ComplianceTask = mongoose.model('ComplianceTask', new mongoose.Schema({
  id: { type: String, required: true, unique: true }, title: String, linked: String, reviewer: String, due: Date,
  status: { type: String, enum: ['Pending', 'Submitted', 'Under Review', 'Approved', 'Needs Action', 'Expired'], default: 'Pending' },
}, options))
export const ResearchProject = mongoose.model('ResearchProject', new mongoose.Schema({
  id: { type: String, required: true, unique: true }, title: String, description: String, status: String,
}, options))
export const AuditLog = mongoose.model('AuditLog', new mongoose.Schema({
  user: String, action: String, entityType: String, entityId: String, previousValues: mongoose.Schema.Types.Mixed, updatedValues: mongoose.Schema.Types.Mixed, reason: String,
}, { ...options, immutable: true }))
