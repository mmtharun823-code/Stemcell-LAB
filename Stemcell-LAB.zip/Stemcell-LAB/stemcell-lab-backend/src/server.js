import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import crypto from 'node:crypto'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import cookieParser from 'cookie-parser'

const app = express()
const port = process.env.PORT || 4000
const jwtSecret = process.env.JWT_SECRET || 'local-development-only-secret'
app.use(helmet())
const allowedOrigins = new Set([process.env.CLIENT_ORIGIN, 'http://localhost:5173', 'http://127.0.0.1:5173'].filter(Boolean))
app.use(cors({ origin: (origin, callback) => (!origin || allowedOrigins.has(origin)) ? callback(null, true) : callback(new Error('Origin not allowed')), credentials: true }))
app.use(express.json({ limit: '1mb' }))
app.use(cookieParser())

const users = [
  { id: 'USR-001', name: 'Alex Rivera', email: 'alex@stemcell.local', department: 'Cell Culture', phone: '', role: 'Lab Technician', approved: true, sessionVersion: 0, passwordHash: bcrypt.hashSync('demo1234', 10) },
  { id: 'USR-002', name: 'Morgan Lee', email: 'admin@stemcell.local', department: 'Compliance', phone: '', role: 'Admin', approved: true, sessionVersion: 0, passwordHash: bcrypt.hashSync('demo1234', 10) },
]
const records = {
  samples: [
    { id: 'SMP-2025-0148', type: 'iPSC line', donor: 'DNR-042', project: 'Project Atlas', received: '2025-06-18', status: 'Quality Review', location: 'Vault A · Rack 03', updated: '2h ago' },
    { id: 'SMP-2025-0147', type: 'PBMC', donor: 'DNR-039', project: 'Project Helix', received: '2025-06-17', status: 'Stored', location: 'Vault B · Rack 11', updated: '5h ago' },
    { id: 'SMP-2025-0146', type: 'Fibroblast', donor: 'DNR-037', project: 'Project Atlas', received: '2025-06-16', status: 'Received', location: 'Receiving · Bin 02', updated: 'Yesterday' },
  ],
  donors: [
    { id: 'DNR-042', code: 'DONOR-042', consent: 'Verified', verified: '2025-05-30', samples: 4 },
    { id: 'DNR-039', code: 'DONOR-039', consent: 'Submitted', verified: '—', samples: 2 },
  ],
  batches: [
    { id: 'BCH-2025-0036', samples: 'SMP-2025-0148', project: 'Project Atlas', researcher: 'Dr. Morgan Lee', status: 'Observation Due', updated: 'Today' },
    { id: 'BCH-2025-0035', samples: 'SMP-2025-0144, 0145', project: 'Project Nova', researcher: 'Jamie Chen', status: 'In Progress', updated: 'Yesterday' },
  ],
  storage: [
    { id: 'LOC-A03', facility: 'Research Lab', unit: 'Vault A', position: 'Rack 03', capacity: 96, occupied: 74, status: 'Available' },
    { id: 'LOC-B11', facility: 'Research Lab', unit: 'Vault B', position: 'Rack 11', capacity: 72, occupied: 68, status: 'Near capacity' },
    { id: 'LOC-Q04', facility: 'Receiving', unit: 'Quarantine', position: 'Q-04', capacity: 24, occupied: 12, status: 'Available' },
  ],
  compliance: [
    { id: 'CMP-018', title: 'Consent verification', linked: 'SMP-2025-0148', reviewer: 'Morgan Lee', due: 'Today', status: 'Pending' },
    { id: 'CMP-017', title: 'Quarterly inventory review', linked: 'LOC-B11', reviewer: 'Morgan Lee', due: 'In 2 days', status: 'Under Review' },
    { id: 'CMP-016', title: 'Project Atlas document pack', linked: 'PRJ-ATLAS', reviewer: 'Morgan Lee', due: '24 Jun', status: 'Needs Action' },
  ],
  projects: [
    { id: 'PRJ-ATLAS', title: 'Project Atlas', description: 'Cellular reprogramming research records.', status: 'Active', samples: 12, batches: 4 },
    { id: 'PRJ-HELIX', title: 'Project Helix', description: 'Reference sample characterization study.', status: 'Active', samples: 8, batches: 3 },
    { id: 'PRJ-NOVA', title: 'Project Nova', description: 'Longitudinal research observations.', status: 'On hold', samples: 5, batches: 2 },
  ],
}
const auditLogs = []
const resetTokens = new Map()
const attempts = new Map()
const validStatuses = ['Registered', 'Received', 'Quality Review', 'Stored', 'On Hold', 'Rejected', 'Archived']

const auth = (req, res, next) => {
  const token = req.cookies?.access_token || req.headers.authorization?.replace('Bearer ', '')
  if (!token) return res.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Authentication required' } })
  try {
    req.user = jwt.verify(token, jwtSecret)
    const current = users.find(user => user.id === req.user.id)
    if (!current || current.sessionVersion !== req.user.sessionVersion) throw new Error('stale session')
    next()
  } catch { return res.status(401).json({ error: { code: 'UNAUTHORIZED', message: 'Session expired' } }) }
}
const allow = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : res.status(403).json({ error: { code: 'FORBIDDEN', message: 'Your role cannot perform this action' } })
const moduleAccess = {
  samples: ['Admin', 'Lab Technician', 'Researcher', 'Compliance Officer'],
  donors: ['Admin', 'Compliance Officer'],
  batches: ['Admin', 'Lab Technician', 'Researcher'],
  storage: ['Admin', 'Lab Technician'],
  compliance: ['Admin', 'Compliance Officer'],
  projects: ['Admin', 'Researcher'],
}
const readResource = name => allow(...(moduleAccess[name] || ['Admin']))
const rateLimit = (windowMs, max) => (req, res, next) => {
  const key = `${req.ip}:${req.path}`
  const now = Date.now()
  const entry = attempts.get(key)
  if (!entry || now - entry.started > windowMs) attempts.set(key, { started: now, count: 1 })
  else if (++entry.count > max) return res.status(429).json({ error: { code: 'RATE_LIMITED', message: 'Too many attempts. Try again later.' } })
  next()
}
const publicUser = user => ({ id: user.id, name: user.name, email: user.email, department: user.department, phone: user.phone, role: user.role, approved: user.approved })
const list = (name) => (req, res) => {
  const q = String(req.query.q || '').toLowerCase()
  const items = records[name].filter(item => !q || JSON.stringify(item).toLowerCase().includes(q))
  res.json({ data: items, total: items.length })
}
const create = (name) => (req, res) => {
  const item = { ...req.body, id: req.body.id || `${name.slice(0, 3).toUpperCase()}-${Date.now()}`, updated: 'just now' }
  if (records[name].some(existing => existing.id === item.id)) return res.status(409).json({ error: { code: 'DUPLICATE_ID', message: 'This identifier already exists' } })
  records[name].unshift(item); auditLogs.unshift({ id: crypto.randomUUID(), user: req.user.id, action: 'CREATE', entity: name, entityId: item.id, timestamp: new Date().toISOString() })
  res.status(201).json({ data: item })
}

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'stemcell-lab-api', mode: 'development' }))
app.post('/api/auth/login', rateLimit(15 * 60 * 1000, 8), (req, res) => {
  const user = users.find(candidate => candidate.email === req.body.email)
  if (!user || !bcrypt.compareSync(String(req.body.password || ''), user.passwordHash)) return res.status(401).json({ error: { code: 'INVALID_LOGIN', message: 'Email or password is incorrect' } })
  if (!user.approved) return res.status(403).json({ error: { code: 'PENDING_APPROVAL', message: 'Your account is waiting for administrator approval.' } })
  const token = jwt.sign({ id: user.id, name: user.name, role: user.role, sessionVersion: user.sessionVersion }, jwtSecret, { expiresIn: '8h' })
  res.cookie('access_token', token, { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 8 * 60 * 60 * 1000 })
  res.json({ data: publicUser(user) })
})
app.post('/api/auth/signup', rateLimit(15 * 60 * 1000, 5), (req, res) => {
  const { name, email, password, department } = req.body
  if (!name || !/^\S+@\S+\.\S+$/.test(email || '') || !password || password.length < 8) return res.status(422).json({ error: { code: 'INVALID_INPUT', message: 'Use a valid email and password with at least 8 characters.' } })
  if (users.some(user => user.email === email.toLowerCase())) return res.status(409).json({ error: { code: 'DUPLICATE_EMAIL', message: 'An account with this email already exists.' } })
  const user = { id: `USR-${String(users.length + 1).padStart(3, '0')}`, name: name.trim(), email: email.toLowerCase(), department: department || '', phone: '', role: 'Researcher', approved: false, sessionVersion: 0, passwordHash: bcrypt.hashSync(password, 12) }
  users.push(user)
  auditLogs.unshift({ id: crypto.randomUUID(), action: 'REGISTER', entity: 'users', entityId: user.id, timestamp: new Date().toISOString() })
  res.status(201).json({ data: { message: 'Registration received. An administrator must approve your account before you can sign in.' } })
})
app.post('/api/auth/logout', (_req, res) => res.clearCookie('access_token').status(204).end())
app.get('/api/auth/me', auth, (req, res) => { const user = users.find(candidate => candidate.id === req.user.id); res.json({ data: publicUser(user) }) })
app.patch('/api/auth/profile', auth, (req, res) => {
  const user = users.find(candidate => candidate.id === req.user.id)
  if (typeof req.body.name !== 'string' || req.body.name.trim().length < 2) return res.status(422).json({ error: { code: 'INVALID_NAME', message: 'Name must contain at least 2 characters.' } })
  user.name = req.body.name.trim(); user.department = String(req.body.department || '').trim(); user.phone = String(req.body.phone || '').trim()
  auditLogs.unshift({ id: crypto.randomUUID(), user: user.id, action: 'PROFILE_UPDATE', entity: 'users', entityId: user.id, timestamp: new Date().toISOString() })
  res.json({ data: publicUser(user) })
})
app.post('/api/auth/change-password', auth, rateLimit(15 * 60 * 1000, 5), (req, res) => {
  const user = users.find(candidate => candidate.id === req.user.id)
  if (!bcrypt.compareSync(String(req.body.currentPassword || ''), user.passwordHash)) return res.status(422).json({ error: { code: 'INVALID_PASSWORD', message: 'Current password is incorrect.' } })
  if (!req.body.newPassword || req.body.newPassword.length < 8 || req.body.newPassword !== req.body.confirmPassword) return res.status(422).json({ error: { code: 'INVALID_PASSWORD', message: 'New passwords must match and contain at least 8 characters.' } })
  user.passwordHash = bcrypt.hashSync(req.body.newPassword, 12); user.sessionVersion += 1
  auditLogs.unshift({ id: crypto.randomUUID(), user: user.id, action: 'PASSWORD_CHANGE', entity: 'users', entityId: user.id, timestamp: new Date().toISOString() })
  res.clearCookie('access_token').json({ data: { message: 'Password changed. Please sign in again.' } })
})
app.post('/api/auth/forgot-password', rateLimit(15 * 60 * 1000, 5), (req, res) => {
  const user = users.find(candidate => candidate.email === String(req.body.email || '').toLowerCase())
  if (user) resetTokens.set(crypto.randomUUID(), { userId: user.id, expires: Date.now() + 15 * 60 * 1000 })
  res.json({ data: { message: 'If an account exists for that email, a reset link will be available shortly.' } })
})
app.post('/api/auth/reset-password', rateLimit(15 * 60 * 1000, 5), (req, res) => {
  const record = resetTokens.get(req.body.token)
  if (!record || record.expires < Date.now()) return res.status(400).json({ error: { code: 'INVALID_RESET', message: 'This reset link is invalid or expired.' } })
  const user = users.find(candidate => candidate.id === record.userId)
  if (!req.body.password || req.body.password.length < 8 || req.body.password !== req.body.confirmPassword) return res.status(422).json({ error: { code: 'INVALID_PASSWORD', message: 'Passwords must match and contain at least 8 characters.' } })
  user.passwordHash = bcrypt.hashSync(req.body.password, 12); user.sessionVersion += 1; resetTokens.delete(req.body.token)
  res.json({ data: { message: 'Password reset successfully. You can now sign in.' } })
})
app.get('/api/dashboard', auth, (_req, res) => res.json({ data: { activeSamples: 248, cultureBatches: 36, pendingReviews: 12, storageLocations: 18 } }))

for (const resource of Object.keys(records)) {
  app.get(`/api/${resource}`, auth, readResource(resource), list(resource))
  app.post(`/api/${resource}`, auth, allow('Admin', 'Lab Technician', 'Researcher', 'Compliance Officer'), create(resource))
}
app.patch('/api/samples/:id', auth, allow('Admin', 'Lab Technician'), (req, res) => {
  const sample = records.samples.find(item => item.id === req.params.id)
  if (!sample) return res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Sample not found' } })
  if (req.body.status && !validStatuses.includes(req.body.status)) return res.status(422).json({ error: { code: 'INVALID_STATUS', message: 'Unsupported sample status' } })
  Object.assign(sample, req.body, { updated: 'just now' })
  auditLogs.unshift({ id: crypto.randomUUID(), user: req.user.id, action: 'UPDATE', entity: 'samples', entityId: sample.id, timestamp: new Date().toISOString() })
  res.json({ data: sample })
})
app.get('/api/audit-logs', auth, allow('Admin', 'Compliance Officer'), (_req, res) => res.json({ data: auditLogs, total: auditLogs.length }))
app.get('/api/reports/summary', auth, (_req, res) => res.json({ data: { samplesByStatus: { Stored: 183, 'Quality Review': 12, Received: 19, Registered: 34 }, compliance: { pending: 12, approved: 31 }, storageOccupancy: 74 } }))
app.use((_req, res) => res.status(404).json({ error: { code: 'NOT_FOUND', message: 'Route not found' } }))
app.listen(port, () => console.log(`StemCell Lab API listening on http://localhost:${port}`))
