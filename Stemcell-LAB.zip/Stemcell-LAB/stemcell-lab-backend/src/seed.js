import 'dotenv/config'
import mongoose from 'mongoose'
import bcrypt from 'bcryptjs'
import { User, Donor, Sample, ResearchProject } from './models.js'

const uri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/stemcell-lab'
await mongoose.connect(uri)
await Promise.all([User.deleteMany({}), Donor.deleteMany({}), Sample.deleteMany({}), ResearchProject.deleteMany({})])
await User.create([
  { name: 'Alex Rivera', email: 'alex@stemcell.local', passwordHash: await bcrypt.hash('demo1234', 10), role: 'Lab Technician' },
  { name: 'Morgan Lee', email: 'admin@stemcell.local', passwordHash: await bcrypt.hash('demo1234', 10), role: 'Admin' },
])
await Donor.create([{ id: 'DNR-042', pseudonymousCode: 'DONOR-042', consentStatus: 'Verified' }, { id: 'DNR-039', pseudonymousCode: 'DONOR-039', consentStatus: 'Submitted' }])
await Sample.create([{ id: 'SMP-2025-0148', type: 'iPSC line', donor: 'DNR-042', status: 'Quality Review' }, { id: 'SMP-2025-0147', type: 'PBMC', donor: 'DNR-039', status: 'Stored' }])
await ResearchProject.create([{ id: 'PRJ-ATLAS', title: 'Project Atlas', description: 'Cellular reprogramming research records.', status: 'Active' }])
await mongoose.disconnect()
console.log('Seeded fictional StemCell Lab records.')
