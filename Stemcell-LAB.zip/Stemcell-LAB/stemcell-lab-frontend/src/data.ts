import type { Sample, Task } from './types'

export const samples: Sample[] = [
  { id: 'SMP-2025-0148', type: 'iPSC line', donor: 'DNR-042', project: 'Project Atlas', received: '18 Jun 2025', status: 'Quality Review', location: 'Vault A · Rack 03', updated: '2h ago' },
  { id: 'SMP-2025-0147', type: 'PBMC', donor: 'DNR-039', project: 'Project Helix', received: '17 Jun 2025', status: 'Stored', location: 'Vault B · Rack 11', updated: '5h ago' },
  { id: 'SMP-2025-0146', type: 'Fibroblast', donor: 'DNR-037', project: 'Project Atlas', received: '16 Jun 2025', status: 'Received', location: 'Receiving · Bin 02', updated: 'Yesterday' },
  { id: 'SMP-2025-0145', type: 'iPSC line', donor: 'DNR-034', project: 'Project Nova', received: '15 Jun 2025', status: 'On Hold', location: 'Quarantine · Q-04', updated: 'Yesterday' },
  { id: 'SMP-2025-0144', type: 'PBMC', donor: 'DNR-031', project: 'Project Helix', received: '14 Jun 2025', status: 'Stored', location: 'Vault A · Rack 02', updated: '2d ago' },
  { id: 'SMP-2025-0143', type: 'Organoid', donor: 'DNR-029', project: 'Project Nova', received: '13 Jun 2025', status: 'Registered', location: '—', updated: '3d ago' },
]

export const tasks: Task[] = [
  { id: 'CMP-018', title: 'Consent verification', description: 'Confirm reference for SMP-2025-0148', due: 'Due today', status: 'Pending' },
  { id: 'CMP-017', title: 'Quarterly inventory review', description: 'Vault B occupancy documentation', due: 'Due in 2 days', status: 'Under Review' },
  { id: 'CMP-016', title: 'Project Atlas document pack', description: 'Review supporting research evidence', due: 'Due 24 Jun', status: 'Needs Action' },
]

export const chartData = [
  { day: 'Jun 12', observations: 18, batches: 8 },
  { day: 'Jun 13', observations: 25, batches: 10 },
  { day: 'Jun 14', observations: 21, batches: 12 },
  { day: 'Jun 15', observations: 31, batches: 15 },
  { day: 'Jun 16', observations: 28, batches: 17 },
  { day: 'Jun 17', observations: 39, batches: 19 },
  { day: 'Jun 18', observations: 46, batches: 22 },
]
