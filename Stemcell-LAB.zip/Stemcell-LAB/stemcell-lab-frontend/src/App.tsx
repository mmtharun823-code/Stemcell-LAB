import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import {
  Activity, Archive, ArrowUpRight, Bell, Boxes, ChevronDown, ClipboardCheck, Database, FileBarChart,
  FlaskConical, LayoutDashboard, Menu, Microscope, Plus, Search, Settings, ShieldCheck, Sparkles,
  Users, X, Zap, Eye, EyeOff, LockKeyhole, LogOut, Mail, Phone, UserRound,
} from 'lucide-react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts'
import { chartData, samples, tasks } from './data'
import type { Page, SampleStatus } from './types'

const navItems: Array<{ id: Page; label: string; icon: typeof Activity }> = [
  { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
  { id: 'samples', label: 'Samples', icon: FlaskConical },
  { id: 'donors', label: 'Donors', icon: Users },
  { id: 'culture', label: 'Culture batches', icon: Microscope },
  { id: 'storage', label: 'Storage inventory', icon: Boxes },
  { id: 'compliance', label: 'Compliance', icon: ShieldCheck },
  { id: 'research', label: 'Research projects', icon: Archive },
  { id: 'reports', label: 'Reports', icon: FileBarChart },
]
type AuthUser = { id: string; name: string; email: string; department?: string; phone?: string; role: string; approved: boolean }
type AuthMode = 'login' | 'signup' | 'forgot' | 'reset'
const api = async (path: string, options: RequestInit = {}) => {
  let response: Response
  try {
    response = await fetch(`http://127.0.0.1:4000${path}`, { ...options, credentials: 'include', headers: { 'Content-Type': 'application/json', ...(options.headers || {}) } })
  } catch {
    throw new Error('The StemLab sign-in service is offline. Start the app with “npm run dev”, then try again.')
  }
  const body = await response.json().catch(() => ({}))
  if (!response.ok) throw new Error(body.error?.message || 'Something went wrong')
  return body.data
}

const statusClass: Record<SampleStatus | string, string> = {
  Stored: 'success', 'Quality Review': 'info', Received: 'neutral', Registered: 'neutral',
  'On Hold': 'warning', Rejected: 'danger', Archived: 'muted', Pending: 'warning',
  'Under Review': 'info', 'Needs Action': 'danger', Approved: 'success',
}
const initials = (name: string) => name.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join('').toUpperCase()

function App() {
  const [authUser, setAuthUser] = useState<AuthUser | null>(null)
  const [authMode, setAuthMode] = useState<AuthMode>('login')
  const [authLoading, setAuthLoading] = useState(true)
  const [page, setPage] = useState<Page>('dashboard')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [profileMenuOpen, setProfileMenuOpen] = useState(false)
  const profileMenuRef = useRef<HTMLDivElement>(null)
  const [query, setQuery] = useState('')
  const [showAdd, setShowAdd] = useState(false)
  const [toast, setToast] = useState('')
  useEffect(() => { api('/api/auth/me').then(setAuthUser).catch(() => {}).finally(() => setAuthLoading(false)) }, [])
  useEffect(() => {
    if (!profileMenuOpen) return
    const closeOnOutsideTouch = (event: PointerEvent) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target as Node)) setProfileMenuOpen(false)
    }
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setProfileMenuOpen(false) }
    document.addEventListener('pointerdown', closeOnOutsideTouch)
    document.addEventListener('keydown', closeOnEscape)
    return () => {
      document.removeEventListener('pointerdown', closeOnOutsideTouch)
      document.removeEventListener('keydown', closeOnEscape)
    }
  }, [profileMenuOpen])

  const filteredSamples = useMemo(() => samples.filter((sample) =>
    `${sample.id} ${sample.type} ${sample.project} ${sample.status}`.toLowerCase().includes(query.toLowerCase()),
  ), [query])

  const navigate = (next: Page) => { setPage(next); setSidebarOpen(false) }
  const notify = (message: string) => { setToast(message); window.setTimeout(() => setToast(''), 2800) }

  if (authLoading) return <div className="auth-loading"><div className="brand-mark"><FlaskConical size={20} /></div><span>Warming up your workspace...</span></div>
  if (!authUser) return <AuthScreen mode={authMode} setMode={setAuthMode} onLogin={setAuthUser} />
  return (
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''} ${sidebarCollapsed ? 'collapsed' : ''}`}>
        <div className="brand">
          <button className="brand-toggle" onClick={() => { if (window.innerWidth > 700) setSidebarCollapsed(!sidebarCollapsed) }} aria-label={sidebarCollapsed ? 'Expand navigation' : 'Collapse navigation'} title={sidebarCollapsed ? 'Expand navigation' : 'Collapse navigation'}><div className="brand-mark"><FlaskConical size={20} /></div></button>
          <div><strong>StemCell</strong><span>LAB</span></div>
          <button className="icon-button mobile-close" onClick={() => setSidebarOpen(false)} aria-label="Close navigation"><X size={18} /></button>
        </div>
        <div className="workspace-switcher"><div className="workspace-avatar">RL</div><div><b>Research Lab</b><small>Academic workspace</small></div><ChevronDown size={15} /></div>
        <nav aria-label="Main navigation">
          <p className="nav-label">Workspace</p>
          {navItems.map(({ id, label, icon: Icon }) => <button key={id} className={`nav-item ${page === id ? 'active' : ''}`} onClick={() => navigate(id)}><Icon size={18} /><span>{label}</span>{id === 'compliance' && <em>3</em>}</button>)}
        </nav>
        <div className="sidebar-footer"><div className="help-card"><Sparkles size={17} /><div><b>Need a hand?</b><small>Explore the quick guide</small></div><ArrowUpRight size={15} /></div><div className="profile"><div className="avatar">{initials(authUser.name)}</div><div><b>{authUser.name}</b><small>{authUser.role}</small></div><ChevronDown size={15} /></div></div>
      </aside>
      {sidebarOpen && <button className="scrim" onClick={() => setSidebarOpen(false)} aria-label="Close navigation overlay" />}
      <main className="main">
        <header className="topbar">
          <button className="icon-button mobile-menu" onClick={() => setSidebarOpen(true)} aria-label="Open navigation"><Menu size={20} /></button>
          <div className="breadcrumbs"><span>Workspace</span><b>/</b><strong>{navItems.find(item => item.id === page)?.label}</strong></div>
          <div className="top-actions"><div className="global-search"><Search size={17} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search records..." aria-label="Search records" /><kbd>⌘ K</kbd></div><button className="icon-button notification" aria-label="Notifications"><Bell size={19} /><i /></button><div className="profile-menu-wrap" ref={profileMenuRef}><button className="top-avatar profile-trigger" onClick={() => setProfileMenuOpen(!profileMenuOpen)} aria-label="Open profile menu" aria-expanded={profileMenuOpen}>{initials(authUser.name)}</button>{profileMenuOpen && <div className="profile-menu"><div className="profile-menu-head"><div className="menu-avatar">{initials(authUser.name)}</div><div><b>{authUser.name}</b><small>{authUser.role}</small></div></div><div className="profile-menu-divider" /><button onClick={() => { setProfileMenuOpen(false); navigate('profile') }}><UserRound size={16} /> Update profile</button><button onClick={() => { setProfileMenuOpen(false); navigate('password') }}><LockKeyhole size={16} /> Change password</button><div className="profile-menu-divider" /><button className="menu-logout" onClick={async () => { setProfileMenuOpen(false); await api('/api/auth/logout', { method: 'POST' }); setAuthUser(null) }}><LogOut size={16} /> Logout</button></div>}</div></div>
        </header>
        <div className="page-content">
          {page === 'dashboard' ? <Dashboard user={authUser} navigate={navigate} onAdd={() => setShowAdd(true)} notify={notify} /> : page === 'profile' ? <ProfilePage user={authUser} setUser={setAuthUser} notify={notify} /> : page === 'password' ? <PasswordPage onLogout={() => setAuthUser(null)} notify={notify} /> : <ModulePage page={page} samples={filteredSamples} query={query} setQuery={setQuery} onAdd={() => setShowAdd(true)} notify={notify} />}
        </div>
      </main>
      {showAdd && <AddSampleModal close={() => setShowAdd(false)} notify={notify} />}
      {toast && <div className="toast"><Zap size={17} />{toast}</div>}
    </div>
  )
}

function Dashboard({ user, navigate, onAdd, notify }: { user: AuthUser; navigate: (page: Page) => void; onAdd: () => void; notify: (message: string) => void }) {
  return <><section className="hero-row"><div><p className="eyebrow">Wednesday · 18 JUN 2025 <span className="live-pill"><i /> Live workspace</span></p><h1>Welcome to StemLab, {user.name}! <span>✦</span></h1><p className="muted">Your research workspace is ready. Here’s the pulse.</p></div><button className="primary-button" onClick={onAdd}><Plus size={18} /> Add sample</button></section>
    <div className="metric-grid"><Metric icon={FlaskConical} label="Active samples" value="248" detail="+12% from last month" trend="up" color="teal" /><Metric icon={Activity} label="Culture batches" value="36" detail="8 observations due" trend="neutral" color="blue" /><Metric icon={ClipboardCheck} label="Pending reviews" value="12" detail="3 due this week" trend="warning" color="orange" /><Metric icon={Database} label="Storage locations" value="18" detail="74% average occupancy" trend="neutral" color="purple" /></div>
    <div className="dashboard-grid"><section className="card workflow-card"><CardHeader title="Sample workflow" action="View all samples" onClick={() => navigate('samples')} /><p className="card-subtitle">Record distribution across the sample lifecycle</p><div className="workflow">{[['Registered', 34], ['Received', 19], ['Quality review', 12], ['Stored', 183], ['Archived', 21]].map(([label, count], index) => <button className="workflow-step" key={label} onClick={() => navigate('samples')}><div className={`workflow-icon step-${index}`}><span>{count}</span></div><b>{label}</b>{index < 4 && <div className="workflow-line" />}</button>)}</div></section>
      <section className="card insights-card"><CardHeader title="AI insights" action="Rule-based demo" /><p className="card-subtitle">Administrative signals from your records</p><Insight icon="↗" title="Reviews approaching" text="Three documentation tasks are approaching their due date." count="3 tasks" onClick={() => navigate('compliance')} /><Insight icon="!" title="Quality review queue" text="Two samples are awaiting quality review." count="2 samples" onClick={() => navigate('samples')} /><Insight icon="⌁" title="Inventory attention" text="Some storage records need an occupancy update." count="4 locations" onClick={() => navigate('storage')} /><button className="text-button" onClick={() => notify('Insights marked as reviewed')}><ClipboardCheck size={15} /> Mark all as reviewed</button></section>
    </div>
    <div className="dashboard-grid lower-grid"><section className="card table-card"><CardHeader title="Recent samples" action="View all" onClick={() => navigate('samples')} /><SampleTable compact onOpen={() => navigate('samples')} /></section><section className="card chart-card"><CardHeader title="Culture activity" action="Last 7 days" /><p className="card-subtitle">Recorded observations and active batches</p><div className="chart-legend"><span><i className="dot teal-dot" />Observations</span><span><i className="dot blue-dot" />Active batches</span></div><ResponsiveContainer width="100%" height={195}><AreaChart data={chartData} margin={{ top: 8, right: 4, left: -25, bottom: 0 }}><defs><linearGradient id="obs" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#0f8b8d" stopOpacity=".24" /><stop offset="100%" stopColor="#0f8b8d" stopOpacity="0" /></linearGradient></defs><CartesianGrid stroke="#edf1f5" vertical={false} /><XAxis dataKey="day" tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} /><YAxis tick={{ fontSize: 11, fill: '#94a3b8' }} axisLine={false} tickLine={false} /><Tooltip contentStyle={{ border: '1px solid #e2e8f0', borderRadius: 10, fontSize: 12 }} /><Area type="monotone" dataKey="observations" stroke="#0f8b8d" fill="url(#obs)" strokeWidth={2.5} /><Area type="monotone" dataKey="batches" stroke="#5b8def" fill="none" strokeWidth={2} /></AreaChart></ResponsiveContainer></section></div>
    <section className="card activity-card"><CardHeader title="Recent activity" action="View audit log" onClick={() => notify('Audit log access is limited to authorized roles')} /><div className="activity-list"><ActivityRow icon="✓" title="Quality review completed" desc="SMP-2025-0144 was marked as Stored" time="24 min ago" color="green" /><ActivityRow icon="+" title="New sample registered" desc="SMP-2025-0148 was added by you" time="2 hours ago" color="teal" /><ActivityRow icon="↻" title="Culture observation updated" desc="BCH-2025-0036 received a new observation" time="4 hours ago" color="blue" /><ActivityRow icon="!" title="Documentation needs attention" desc="Consent verification for DNR-042 is pending" time="Yesterday" color="orange" /></div></section>
  </>
}

function AuthScreen({ mode, setMode, onLogin }: { mode: AuthMode; setMode: (mode: AuthMode) => void; onLogin: (user: AuthUser) => void }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '', department: '' })
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')
  const submit = async (event: FormEvent) => {
    event.preventDefault(); setError(''); setMessage(''); setLoading(true)
    try {
      if (mode === 'login') onLogin(await api('/api/auth/login', { method: 'POST', body: JSON.stringify({ email: form.email, password: form.password }) }))
      else if (mode === 'signup') { if (form.password !== form.confirmPassword) throw new Error('Passwords do not match.'); const result = await api('/api/auth/signup', { method: 'POST', body: JSON.stringify(form) }); setMessage(result.message); setMode('login') }
      else if (mode === 'forgot') { const result = await api('/api/auth/forgot-password', { method: 'POST', body: JSON.stringify({ email: form.email }) }); setMessage(result.message) }
      else { await api('/api/auth/reset-password', { method: 'POST', body: JSON.stringify({ token: new URLSearchParams(window.location.search).get('token'), password: form.password, confirmPassword: form.confirmPassword }) }); setMessage('Password reset. You can sign in now.'); setMode('login') }
    } catch (caught) { setError(caught instanceof Error ? caught.message : 'Unable to complete this request.') } finally { setLoading(false) }
  }
  const isLogin = mode === 'login'
  const isSignup = mode === 'signup'
  const title = isLogin ? 'Welcome back, researcher.' : isSignup ? 'Make your mark in the lab.' : mode === 'forgot' ? 'Lost your access?' : 'Set a fresh key.'
  return <div className="auth-page"><div className="auth-art"><div className="auth-orbit orbit-one" /><div className="auth-orbit orbit-two" /><div className="auth-art-copy"><div className="brand auth-brand"><div className="brand-mark"><FlaskConical size={21} /></div><div><strong>StemCell</strong><span>LAB</span></div></div><p className="auth-kicker">RESEARCH / RECORDS / REAL IMPACT</p><h1>Keep your<br /><em>curiosity</em> moving.</h1><p>One calm place for every sample, observation, and decision trail.</p><div className="auth-sticker"><Sparkles size={15} /> Built for brave lab work</div></div><div className="cell-shape">✦</div></div><div className="auth-panel"><div className="auth-panel-inner"><div className="auth-mobile-brand"><div className="brand-mark"><FlaskConical size={19} /></div><b>StemCell <span>LAB</span></b></div><div className="auth-heading"><span className="auth-step">{isLogin ? '01 / SIGN IN' : isSignup ? '02 / JOIN THE LAB' : '03 / ACCOUNT ACCESS'}</span><h2>{title}</h2><p>{isLogin ? 'Your research workspace is ready when you are.' : isSignup ? 'New accounts start as Researchers and need admin approval.' : 'No stress. We’ll help you get back in safely.'}</p></div>{error && <div className="auth-alert error">{error}</div>}{message && <div className="auth-alert success">{message}</div>}<form onSubmit={submit} className="auth-form">{isSignup && <label>Full name<input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Alex Rivera" /></label>}<label><Mail size={15} /> Email address<input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@researchlab.edu" /></label>{isSignup && <label>Department <input value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} placeholder="e.g. Cell Culture" /></label>}{mode !== 'forgot' && <><label><LockKeyhole size={15} /> {mode === 'reset' ? 'New password' : 'Password'}<span className="password-input"><input required minLength={8} type={showPassword ? 'text' : 'password'} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="8+ characters" /><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label="Show or hide password">{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>{(isSignup || mode === 'reset') && <label>Confirm password<span className="password-input"><input required minLength={8} type={showPassword ? 'text' : 'password'} value={form.confirmPassword} onChange={e => setForm({ ...form, confirmPassword: e.target.value })} placeholder="Repeat your password" /><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label="Show or hide password">{showPassword ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>}</>}{isLogin && <div className="auth-row"><label className="check-label"><input type="checkbox" /> Keep me signed in</label><button type="button" className="auth-link" onClick={() => setMode('forgot')}>Forgot password?</button></div>}<button className="primary-button auth-submit" disabled={loading}>{loading ? 'One sec...' : isLogin ? 'Enter workspace' : isSignup ? 'Request access' : mode === 'forgot' ? 'Send secure link' : 'Reset password'} <ArrowUpRight size={16} /></button></form><div className="auth-switch">{isLogin ? <>New to the lab? <button onClick={() => setMode('signup')}>Create an account <ArrowUpRight size={13} /></button></> : <>Already have access? <button onClick={() => setMode('login')}>Sign in <ArrowUpRight size={13} /></button></>}</div><small className="auth-disclaimer">Fictional academic workspace · No clinical decisions are made here.</small></div></div></div>
}

function ProfilePage({ user, setUser, notify }: { user: AuthUser; setUser: (user: AuthUser) => void; notify: (message: string) => void }) {
  const [form, setForm] = useState({ name: user.name, department: user.department || '', phone: user.phone || '' })
  const [saving, setSaving] = useState(false)
  return <><section className="hero-row module-hero hero-profile"><div><p className="eyebrow">Account / Profile ✦</p><h1>Your profile</h1><p className="muted">Keep your workspace identity and contact details current.</p></div><div className="profile-orb">{user.name.split(' ').map(part => part[0]).join('')}</div></section><section className="account-grid"><div className="card account-card"><div className="account-card-heading"><div className="profile-large">{user.name.split(' ').map(part => part[0]).join('')}</div><div><h2>{user.name}</h2><p>{user.role} · {user.email}</p></div></div><div className="role-chip"><ShieldCheck size={14} /> Role managed by administrators</div><form className="account-form" onSubmit={async e => { e.preventDefault(); setSaving(true); try { setUser(await api('/api/auth/profile', { method: 'PATCH', body: JSON.stringify(form) })); notify('Profile saved'); } catch (error) { notify(error instanceof Error ? error.message : 'Could not save profile') } finally { setSaving(false) } }}><label>Display name<input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} /></label><label><Phone size={14} /> Phone number<input value={form.phone} onChange={e => setForm({ ...form, phone: e.target.value })} placeholder="+91 ..." /></label><label>Department<input value={form.department} onChange={e => setForm({ ...form, department: e.target.value })} placeholder="Research team" /></label><label>Email address<input value={user.email} disabled /></label><button className="primary-button" disabled={saving}>{saving ? 'Saving...' : 'Save profile'}</button></form></div><div className="card account-side"><Sparkles size={22} /><h2>Your access</h2><p>Your role controls which records and actions are available. If you need more access, ask an administrator.</p><div className="access-row"><span>Role</span><b>{user.role}</b></div><div className="access-row"><span>Approval</span><b className="approved"><i /> Approved</b></div></div></section></>
}

function PasswordPage({ onLogout, notify }: { onLogout: () => void; notify: (message: string) => void }) {
  const [form, setForm] = useState({ currentPassword: '', newPassword: '', confirmPassword: '' }); const [show, setShow] = useState(false); const [saving, setSaving] = useState(false)
  return <><section className="hero-row module-hero hero-password"><div><p className="eyebrow">Account / Security ✦</p><h1>Change password</h1><p className="muted">A fresh key keeps your research space yours.</p></div></section><div className="card password-card"><div className="security-icon"><LockKeyhole size={22} /></div><h2>Update your password</h2><p>Use at least 8 characters. You’ll be signed out of this session when it changes.</p><form className="account-form" onSubmit={async e => { e.preventDefault(); setSaving(true); try { const result = await api('/api/auth/change-password', { method: 'POST', body: JSON.stringify(form) }); notify(result.message); onLogout() } catch (error) { notify(error instanceof Error ? error.message : 'Could not change password') } finally { setSaving(false) } }}>{(['currentPassword', 'newPassword', 'confirmPassword'] as const).map((field, index) => <label key={field}>{index === 0 ? 'Current password' : index === 1 ? 'New password' : 'Confirm new password'}<span className="password-input"><input required minLength={8} type={show ? 'text' : 'password'} value={form[field]} onChange={e => setForm({ ...form, [field]: e.target.value })} /><button type="button" onClick={() => setShow(!show)} aria-label="Show or hide password">{show ? <EyeOff size={16} /> : <Eye size={16} />}</button></span></label>)}<div className="password-hint"><i /> Strong password <span>•</span> 8+ characters <span>•</span> Mix letters and numbers</div><button className="primary-button" disabled={saving}>{saving ? 'Updating...' : 'Update password'}</button></form></div></>
}

function Metric({ icon: Icon, label, value, detail, trend, color }: { icon: typeof Activity; label: string; value: string; detail: string; trend: string; color: string }) { return <div className="metric-card"><div className={`metric-icon ${color}`}><Icon size={19} /></div><div className="metric-copy"><span>{label}</span><strong>{value}</strong><small className={trend === 'up' ? 'positive' : trend === 'warning' ? 'warning-text' : ''}>{trend === 'up' && '↗ '}{detail}</small></div><ArrowUpRight size={16} className="metric-arrow" /></div> }
function CardHeader({ title, action, onClick }: { title: string; action: string; onClick?: () => void }) { return <div className="card-header"><h2>{title}</h2><button className="card-action" onClick={onClick}>{action}<ArrowUpRight size={14} /></button></div> }
function Insight({ icon, title, text, count, onClick }: { icon: string; title: string; text: string; count: string; onClick: () => void }) { return <div className="insight"><div className="insight-icon">{icon}</div><div className="insight-content"><b>{title}</b><p>{text}</p><button onClick={onClick}>{count} <ArrowUpRight size={12} /></button></div></div> }
function ActivityRow({ icon, title, desc, time, color }: { icon: string; title: string; desc: string; time: string; color: string }) { return <div className="activity-row"><div className={`activity-icon ${color}`}>{icon}</div><div><b>{title}</b><p>{desc}</p></div><time>{time}</time></div> }
function SampleTable({ compact = false, onOpen }: { compact?: boolean; onOpen: () => void }) { return <div className="table-wrap"><table><thead><tr><th>Sample ID</th><th>Type</th><th>Status</th><th>Location</th><th>Updated</th><th /></tr></thead><tbody>{samples.slice(0, compact ? 4 : samples.length).map(sample => <tr key={sample.id}><td><button className="record-link" onClick={onOpen}>{sample.id}</button></td><td>{sample.type}</td><td><span className={`status ${statusClass[sample.status]}`}>{sample.status}</span></td><td>{sample.location}</td><td>{sample.updated}</td><td><button className="kebab" onClick={onOpen}>•••</button></td></tr>)}</tbody></table></div> }
function ModulePage({ page, samples: visibleSamples, query, setQuery, onAdd, notify }: { page: Exclude<Page, 'dashboard' | 'profile' | 'password'>; samples: typeof samples; query: string; setQuery: (value: string) => void; onAdd: () => void; notify: (message: string) => void }) {
  const titles: Record<Page, [string, string]> = { dashboard: ['Overview', ''], samples: ['Samples', 'Track every sample record from registration to archive.'], donors: ['Donor registry', 'Pseudonymous donor references and consent documentation.'], culture: ['Culture batches', 'Research observations and passage records.'], storage: ['Storage inventory', 'Monitor location capacity and authorized movements.'], compliance: ['Compliance center', 'Documentation reviews and upcoming deadlines.'], research: ['Research projects', 'Keep project records, samples, and batches connected.'], reports: ['Reports & exports', 'Aggregate operational summaries for authorized users.'], profile: ['Your profile', ''], password: ['Change password', ''] }
  const [title, subtitle] = titles[page]
  return <><section className={`hero-row module-hero hero-${page}`}><div><p className="eyebrow">Workspace / {title} <span className="hero-slash">✦</span></p><h1>{title}</h1><p className="muted">{subtitle}</p></div>{page === 'samples' && <button className="primary-button" onClick={onAdd}><Plus size={18} /> Add sample</button>}{page === 'reports' && <button className="primary-button" onClick={() => exportReport(notify)}><FileBarChart size={17} /> Export CSV</button>}</section><section className={`card module-card module-${page}`}>{page === 'samples' ? <><div className="module-toolbar"><div className="filter-search"><Search size={17} /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search samples, projects, or IDs..." /><button onClick={() => setQuery('')}>Clear</button></div><button className="secondary-button" onClick={() => notify('Filters are ready for your next query')}><ClipboardCheck size={16} /> Filters</button></div><SampleTable onOpen={() => notify('Sample detail view opened')} /></> : <ModuleContent page={page} notify={notify} />}</section></>
}
function ModuleContent({ page, notify }: { page: Exclude<Page, 'dashboard' | 'samples' | 'profile' | 'password'>; notify: (message: string) => void }) {
  const content: Record<Exclude<Page, 'dashboard' | 'samples' | 'profile' | 'password'>, { headers: string[]; rows: string[][] }> = {
    donors: { headers: ['Donor reference', 'Pseudonymous code', 'Consent status', 'Verified', 'Linked samples'], rows: [['DNR-042', 'DONOR-042', 'Verified', '30 May 2025', '4'], ['DNR-039', 'DONOR-039', 'Submitted', '—', '2'], ['DNR-037', 'DONOR-037', 'Needs Review', '—', '3']] },
    culture: { headers: ['Batch ID', 'Linked samples', 'Project', 'Researcher', 'Status'], rows: [['BCH-2025-0036', 'SMP-2025-0148', 'Project Atlas', 'Dr. Morgan Lee', 'Observation Due'], ['BCH-2025-0035', 'SMP-2025-0144, 0145', 'Project Nova', 'Jamie Chen', 'In Progress'], ['BCH-2025-0034', 'SMP-2025-0141', 'Project Helix', 'Dr. Morgan Lee', 'Completed']] },
    storage: { headers: ['Location', 'Facility / unit', 'Position', 'Occupancy', 'Inventory status'], rows: [['LOC-A03', 'Research Lab / Vault A', 'Rack 03', '74 / 96 (77%)', 'Available'], ['LOC-B11', 'Research Lab / Vault B', 'Rack 11', '68 / 72 (94%)', 'Near capacity'], ['LOC-Q04', 'Receiving / Quarantine', 'Q-04', '12 / 24 (50%)', 'Available']] },
    compliance: { headers: ['Task', 'Linked record', 'Reviewer', 'Due', 'Status'], rows: [['Consent verification', 'SMP-2025-0148', 'Morgan Lee', 'Today', 'Pending'], ['Quarterly inventory review', 'LOC-B11', 'Morgan Lee', 'In 2 days', 'Under Review'], ['Project Atlas document pack', 'PRJ-ATLAS', 'Morgan Lee', '24 Jun', 'Needs Action']] },
    research: { headers: ['Project ID', 'Project title', 'Description', 'Records', 'Status'], rows: [['PRJ-ATLAS', 'Project Atlas', 'Cellular reprogramming research records.', '12 samples · 4 batches', 'Active'], ['PRJ-HELIX', 'Project Helix', 'Reference sample characterization study.', '8 samples · 3 batches', 'Active'], ['PRJ-NOVA', 'Project Nova', 'Longitudinal research observations.', '5 samples · 2 batches', 'On hold']] },
    reports: { headers: ['Report', 'Coverage', 'Last generated', 'Access'], rows: [['Sample status summary', '248 records', '18 Jun 2025', 'Authorized'], ['Culture batch activity', '36 batches', '18 Jun 2025', 'Authorized'], ['Compliance task summary', '43 tasks', '18 Jun 2025', 'Authorized']] },
  }
  const data = content[page]
  return <div className="rich-module"><div className="module-summary"><div><span>Workspace records</span><strong>{data.rows.length * 12 + 7}</strong></div><div><span>Last updated</span><strong>Today, 09:14</strong></div><div><span>Access policy</span><strong>Role controlled</strong></div></div><div className="table-wrap"><table><thead><tr>{data.headers.map(header => <th key={header}>{header}</th>)}<th /></tr></thead><tbody>{data.rows.map(row => <tr key={row[0]}>{row.map((cell, index) => <td key={`${row[0]}-${index}`}>{index === row.length - 1 ? <span className={`status ${statusClass[cell] || 'neutral'}`}>{cell}</span> : cell}</td>)}<td><button className="record-link" onClick={() => notify(`${row[0]} detail opened`)}>View <ArrowUpRight size={11} /></button></td></tr>)}</tbody></table></div>{page === 'compliance' && <div className="module-note"><ShieldCheck size={16} /><span>Software statuses support administrative tracking only; authorized people remain responsible for compliance decisions.</span></div>}{page === 'reports' && <div className="report-cards"><div><b>74%</b><span>Average storage occupancy</span></div><div><b>183</b><span>Stored sample records</span></div><div><b>12</b><span>Reviews requiring attention</span></div></div>}</div>
}
function exportReport(notify: (message: string) => void) { const csv = 'Report,Value\\nActive samples,248\\nCulture batches,36\\nPending reviews,12\\nStorage locations,18\\n'; const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' }); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = 'stemcell-lab-summary.csv'; link.click(); URL.revokeObjectURL(url); notify('Report exported as CSV') }
function AddSampleModal({ close, notify }: { close: () => void; notify: (message: string) => void }) { const [id] = useState(`SMP-2025-${String(149 + Math.floor(Math.random() * 20)).padStart(4, '0')}`); return <div className="modal-backdrop" onClick={close}><div className="modal" onClick={e => e.stopPropagation()}><div className="modal-header"><div><p className="eyebrow">New record</p><h2>Add sample</h2></div><button className="icon-button" onClick={close} aria-label="Close dialog"><X size={18} /></button></div><p className="muted">Create a fictional research record. Required fields are marked with <b>*</b>.</p><div className="form-grid"><label>Sample ID*<input value={id} readOnly /></label><label>Sample type*<select defaultValue=""><option value="" disabled>Select type</option><option>iPSC line</option><option>PBMC</option><option>Fibroblast</option><option>Organoid</option></select></label><label>Linked donor*<input placeholder="e.g. DNR-045" /></label><label>Research project<select defaultValue=""><option value="">Select project</option><option>Project Atlas</option><option>Project Helix</option><option>Project Nova</option></select></label><label>Receipt date & time*<input type="datetime-local" defaultValue="2025-06-18T10:30" /></label><label>Assigned technician<input defaultValue="Alex Rivera" /></label><label className="full">Notes<textarea placeholder="Add a short administrative note..." /></label></div><div className="modal-footer"><button className="secondary-button" onClick={close}>Cancel</button><button className="primary-button" onClick={() => { close(); notify('Sample saved to the local demo workspace') }}><Plus size={17} /> Save sample</button></div></div></div> }

export default App
