export type SampleStatus = 'Registered' | 'Received' | 'Quality Review' | 'Stored' | 'On Hold' | 'Rejected' | 'Archived'
export type Page = 'dashboard' | 'samples' | 'donors' | 'culture' | 'storage' | 'compliance' | 'research' | 'reports' | 'profile' | 'password'

export interface Sample {
  id: string
  type: string
  donor: string
  project: string
  received: string
  status: SampleStatus
  location: string
  updated: string
}

export interface Task {
  id: string
  title: string
  description: string
  due: string
  status: 'Pending' | 'Under Review' | 'Needs Action' | 'Approved'
}
